document.getElementById('injectButton').addEventListener('click', () => {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    const currentTab = tabs[0];
    if (currentTab.url.includes('mail.google.com')) {
      chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        files: ['content.js']
      }, (result) => {
         if (chrome.runtime.lastError) {
           console.error('Script injection failed:', chrome.runtime.lastError.message);
         } else {
           console.log('Script injected successfully!');
           // Close the popup
           window.close();
         }
      });
    } else {
      console.log('This extension only works on Gmail.');
      alert('This extension only works on Gmail.');
    }
  });
});