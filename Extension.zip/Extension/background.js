chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Check if the tab has fully loaded and the URL matches Gmail.
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('mail.google.com')) {
    // Programmatically inject the content script.
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }, () => {
      // Add a callback to check for errors.
      if (chrome.runtime.lastError) {
        console.error('Script injection failed:', chrome.runtime.lastError.message);
      } else {
        console.log('Script injected successfully!');
      }
    });
  }
});