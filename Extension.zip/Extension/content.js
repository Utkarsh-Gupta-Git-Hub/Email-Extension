setTimeout(() => {
  console.log("Email Writer Extension - Content Script Loaded (Delayed)");
}, 3000); // 3-second delay